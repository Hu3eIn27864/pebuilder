#!/usr/bin/env python3
"""
PE disassembly reassembler.

Pipeline:

    disasm
       |
       v
    assembler
       |
       v
    linker
       |
       v
    builder


Supports:

    x86
    x64

    EXE
    DLL
"""


import argparse
from pathlib import Path


from .assembler import X86Assembler
from .linker import Linker



# Optional providers

try:
    from .imports import ImportBuilder
except Exception:
    ImportBuilder = None


try:
    from .exports import ExportBuilder
except Exception:
    ExportBuilder = None


try:
    from .reloc import RelocationBuilder
except Exception:
    RelocationBuilder = None


try:
    from .tls import TLSBuilder
except Exception:
    TLSBuilder = None


try:
    from .pdata import PDataBuilder
except Exception:
    PDataBuilder = None


try:
    from .resources import ResourceBuilder
except Exception:
    ResourceBuilder = None


try:
    from .debug import DebugBuilder
except Exception:
    DebugBuilder = None


try:
    from .loadconfig import LoadConfigBuilder
except Exception:
    LoadConfigBuilder = None


try:
    from .bound_imports import BoundImportBuilder
except Exception:
    BoundImportBuilder = None



# ------------------------------------------------------------
# Disassembly parser
# ------------------------------------------------------------

class Disassembly:


    def __init__(self):

        self.instructions = []


    def load(
            self,
            filename
    ):


        with open(
            filename,
            "r",
            encoding="utf-8",
            errors="ignore"
        ) as f:


            for line in f:


                line=line.strip()


                if not line:

                    continue



                if ":" not in line:

                    continue



                address,text = line.split(
                    ":",
                    1
                )


                address = int(
                    address.strip()
                    .replace(
                        "0x",
                        ""
                    ),
                    16
                )


                text = text.strip()


                if ";" in text:

                    text = text.split(
                        ";",
                        1
                    )[0].strip()



                if text:

                    self.instructions.append(

                        (
                            address,
                            text
                        )

                    )


        return self



# ------------------------------------------------------------
# Reassembler
# ------------------------------------------------------------

class Reassembler:


    def __init__(
            self,
            bits=64,
            dll=False
    ):


        self.bits = bits

        self.dll = dll


        self.imports = []

        self.exports = []

        self.resources = None

        self.debug = None

        self.tls = None

        self.load_config = None

        self.bound_imports = None



    # --------------------------------------------------------
    # Add metadata
    # --------------------------------------------------------

    def add_import(
            self,
            dll,
            function
    ):

        self.imports.append(

            (
                dll,
                function

            )

        )



    def add_export(
            self,
            name,
            rva
    ):

        self.exports.append(

            (
                name,
                rva

            )

        )



    # --------------------------------------------------------
    # Build
    # --------------------------------------------------------

    def build(
            self,
            disasm,
            output
    ):


        #
        # Parse assembly
        #

        listing = (

            Disassembly()

            .load(

                disasm

            )

        )



        #
        # Assemble code
        #

        assembler = X86Assembler(

            bits=self.bits

        )


        code,relocations = (

            assembler.assemble_listing(
                listing.instructions
            )

        )



        #
        # Link
        #

        linker = Linker(

            bits=self.bits,

            dll=self.dll

        )



        linker.add_text(

            code,

            entry=0

        )



        # ----------------------------------------------------
        # Imports
        # ----------------------------------------------------

        if self.imports:


            if ImportBuilder:


                imp = ImportBuilder(

                    bits=self.bits

                )


                for dll,fn in self.imports:


                    imp.add(

                        dll,

                        fn

                    )


                linker.register(

                    "imports",

                    imp

                )



        # ----------------------------------------------------
        # Exports
        # ----------------------------------------------------

        if self.exports:


            if ExportBuilder:


                exp = ExportBuilder(

                    bits=self.bits

                )


                for name,rva in self.exports:


                    exp.add(

                        name,

                        rva

                    )


                linker.register(

                    "exports",

                    exp

                )



        # ----------------------------------------------------
        # Relocations
        # ----------------------------------------------------

        if relocations and RelocationBuilder:


            reloc = RelocationBuilder(

                bits=self.bits

            )


            for r in relocations:


                reloc.add(
                    r
                )


            linker.register(

                "reloc",

                reloc

            )



        # ----------------------------------------------------
        # TLS
        # ----------------------------------------------------

        if self.tls and TLSBuilder:


            linker.register(

                "tls",

                self.tls

            )



        # ----------------------------------------------------
        # x64 exception data
        # ----------------------------------------------------

        if self.bits == 64 and PDataBuilder:


            pdata = PDataBuilder()



            linker.register(

                "pdata",

                pdata

            )



        # ----------------------------------------------------
        # Resources
        # ----------------------------------------------------

        if self.resources and ResourceBuilder:


            linker.register(

                "resources",

                self.resources

            )



        # ----------------------------------------------------
        # Debug
        # ----------------------------------------------------

        if self.debug and DebugBuilder:


            linker.register(

                "debug",

                self.debug

            )



        # ----------------------------------------------------
        # Load config
        # ----------------------------------------------------

        if self.load_config and LoadConfigBuilder:


            linker.register(

                "load_config",

                self.load_config

            )



        # ----------------------------------------------------
        # Bound imports
        # ----------------------------------------------------

        if self.bound_imports and BoundImportBuilder:


            linker.register(

                "bound_import",

                self.bound_imports

            )



        return linker.link(

            output

        )



# ------------------------------------------------------------
# CLI
# ------------------------------------------------------------

def main():


    parser = argparse.ArgumentParser()



    parser.add_argument(

        "--disasm",

        required=True

    )


    parser.add_argument(

        "--output",

        required=True

    )


    parser.add_argument(

        "--bits",

        type=int,

        default=64

    )


    parser.add_argument(

        "--dll",

        action="store_true"

    )



    args = parser.parse_args()



    r = Reassembler(

        bits=args.bits,

        dll=args.dll

    )


    r.build(

        args.disasm,

        args.output

    )



    print(

        "created",

        args.output

    )



if __name__ == "__main__":

    main()