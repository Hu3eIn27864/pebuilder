#!/usr/bin/env python3
"""
PE executable/DLL builder.

Compatible with:

    pe.py
    sections.py
    linker.py

Supports:

    PE32
    PE32+

    EXE
    DLL
"""


from pathlib import Path


from .pe import (
    PEFormat,
    align,
    build_dos_header,
    build_nt_headers,
)


from .sections import (
    PESection,
    SectionTable,
    IMAGE_SIZEOF_SECTION_HEADER,
)



# ------------------------------------------------------------
# Data directories
# ------------------------------------------------------------

IMAGE_DIRECTORY_ENTRY_EXPORT = 0
IMAGE_DIRECTORY_ENTRY_IMPORT = 1
IMAGE_DIRECTORY_ENTRY_BASERELOC = 5
IMAGE_DIRECTORY_ENTRY_IAT = 12



# ------------------------------------------------------------
# Builder
# ------------------------------------------------------------

class PEBuilder:


    def __init__(

            self,

            bits=64,

            dll=False,

            image_base=None,

            section_alignment=0x1000,

            file_alignment=0x200

    ):


        self.format = PEFormat(bits)


        self.bits = bits

        self.dll = dll


        self.image_base = (

            image_base

            if image_base is not None

            else self.format.image_base_default

        )


        self.section_alignment = section_alignment

        self.file_alignment = file_alignment



        self.sections = []


        self.entry_point = 0


        self.directories = {}



    # --------------------------------------------------------
    # Add section
    # --------------------------------------------------------

    def add_section(

            self,

            section,

            data=None,

            characteristics=None,

            virtual_address=None,

            raw_pointer=None

    ):


        #
        # New API:
        #
        # builder.add_section(PESection)
        #


        if isinstance(section, PESection):


            self.sections.append(section)

            return



        #
        # Compatibility with linker.py:
        #
        # builder.add_section(
        #       name,
        #       data,
        #       flags,
        #       rva,
        #       raw
        # )
        #


        if data is None:

            raise TypeError(
                "section data missing"
            )


        sec = PESection(

            section,

            characteristics=(
                characteristics
                or 0
            )

        )


        sec.set_data(data)


        if virtual_address is not None:

            sec.virtual_address = virtual_address


        if raw_pointer is not None:

            sec.raw_pointer = raw_pointer



        self.sections.append(sec)



    # --------------------------------------------------------
    # Directory helpers
    # --------------------------------------------------------

    def set_directory(

            self,

            index,

            rva,

            size

    ):

        self.directories[index] = (

            rva,

            size

        )



    def add_import_directory(self, section):

        self.set_directory(

            IMAGE_DIRECTORY_ENTRY_IMPORT,

            section.virtual_address,

            len(section.data)

        )



    def add_export_directory(self, section):

        self.set_directory(

            IMAGE_DIRECTORY_ENTRY_EXPORT,

            section.virtual_address,

            len(section.data)

        )



    def add_reloc_directory(self, section):

        self.set_directory(

            IMAGE_DIRECTORY_ENTRY_BASERELOC,

            section.virtual_address,

            len(section.data)

        )



    def add_iat_directory(self, rva, size):

        self.set_directory(

            IMAGE_DIRECTORY_ENTRY_IAT,

            rva,

            size

        )



    # --------------------------------------------------------
    # Header size
    # --------------------------------------------------------

    def headers_size(self):


        size = (

            0x80

            +

            4

            +

            20

            +

            self.format.optional_size

            +

            len(self.sections)

            *

            IMAGE_SIZEOF_SECTION_HEADER

        )


        return align(

            size,

            self.file_alignment

        )



    # --------------------------------------------------------
    # Calculate sizes
    # --------------------------------------------------------

    def size_of_code(self):


        total = 0


        for sec in self.sections:


            if sec.characteristics & 0x20:

                total += align(

                    len(sec.data),

                    self.file_alignment

                )


        return total



    def size_of_data(self):


        total = 0


        for sec in self.sections:


            if not (
                sec.characteristics & 0x20
            ):

                total += align(

                    len(sec.data),

                    self.file_alignment

                )


        return total



    # --------------------------------------------------------
    # Build image
    # --------------------------------------------------------

    def build(self, filename):


        table = SectionTable(

            section_alignment=
            self.section_alignment,

            file_alignment=
            self.file_alignment

        )


        for sec in self.sections:

            table.add(sec)



        headers_size = self.headers_size()


        table.layout(

            headers_size

        )



        #
        # Build headers
        #

        dos = build_dos_header()



        nt = build_nt_headers(

            self.format,

            len(table.sections),

            self.dll,

            self.image_base,

            self.entry_point
            if self.entry_point
            else (
                table.sections[0].virtual_address
                if table.sections
                else 0
            ),

            (
                table.sections[0].virtual_address
                if table.sections
                else 0
            ),

            self.size_of_code(),

            self.size_of_data(),

            table.size_of_image(),

            headers_size,

            self.section_alignment,

            self.file_alignment,

            self.directories

        )



        image = bytearray()



        image.extend(dos)

        image.extend(nt)

        image.extend(

            table.headers()

        )



        if len(image) < headers_size:


            image.extend(

                b"\x00"
                *
                (
                    headers_size -
                    len(image)
                )

            )



        image.extend(

            table.raw_data()

        )



        Path(filename).write_bytes(

            image

        )


        return filename



    # linker.py compatibility

    def write(self, filename):

        return self.build(filename)





# ------------------------------------------------------------
# Convenience
# ------------------------------------------------------------


def build_exe(

        filename,

        sections,

        bits=64

):


    builder = PEBuilder(

        bits=bits

    )


    for sec in sections:

        builder.add_section(sec)


    return builder.build(filename)





def build_dll(

        filename,

        sections,

        bits=64

):


    builder = PEBuilder(

        bits=bits,

        dll=True

    )


    for sec in sections:

        builder.add_section(sec)


    return builder.build(filename)