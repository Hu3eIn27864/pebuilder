Usage
x64 EXE
python -m pebuilder.reassembler \
    --bits 64 \
    --disasm app.asm \
    --output app.exe
x64 DLL
python -m pebuilder.reassembler \
    --bits 64 \
    --dll \
    --disasm library.asm \
    --output library.dll
x86 EXE
python -m pebuilder.reassembler \
    --bits 32 \
    --disasm app.asm \
    --output app32.exe

One dependency remains before the x64 build chain is complete:

pdata.py

because the new reassembler.py now expects:

PDataBuilder()

to generate:

.pdata
.xdata

for x64 unwind information. Without it, the linker can place those sections but there is no unwind metadata to put inside them.